package com.example.mybiodata.ui.profile

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.mybiodata.R
import com.example.mybiodata.databinding.FragmentProfileBinding

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val profileImageView: ImageView = binding.profileImage
        profileImageView.setImageResource(R.drawable.profil) // Ganti "profil" dengan nama file gambar yang sesuai di drawable

        val usernameTextView: TextView = binding.username
        usernameTextView.text = "Nama          : Hafid Wahyudi"

        val birthDateTextView: TextView = binding.birthDate
        birthDateTextView.text = "Tanggal Lahir     : 03 September 2003"

        val emailTextView: TextView = binding.email
        emailTextView.text = "Email         : hafidwahyudi2003@gmail.com"

        val biodataTextView: TextView = binding.biodata
        biodataTextView.text = getString(R.string.biodata)

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
