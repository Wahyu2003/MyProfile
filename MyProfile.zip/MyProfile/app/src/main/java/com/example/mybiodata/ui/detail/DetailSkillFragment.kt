package com.example.mybiodata.ui.detail

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.example.mybiodata.R
import com.example.mybiodata.databinding.FragmentDetailSkillBinding
import com.example.mybiodata.ui.skill.Skill

class DetailSkillFragment : Fragment() {
    private var _binding: FragmentDetailSkillBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDetailSkillBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val recyclerView = root.findViewById<RecyclerView>(R.id.recyclerViewDetail)
        val logoDetail = binding.logoDetail
        val titleDetail = binding.titleDetail
        val detailSkill = binding.detailSkill

        val bahasaPemrograman = arguments?.getParcelable<Skill>("skill")

        bahasaPemrograman?.let {
            val adapter = DetailSkillAdapter(it)
            recyclerView.adapter = adapter
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
