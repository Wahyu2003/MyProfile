package com.example.mybiodata.ui.skill

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Skill(val logoResource: Int, val title: String, val detail: String) : Parcelable

