package com.example.mybiodata.ui.skill

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mybiodata.R
import com.example.mybiodata.databinding.ItemSkillBinding
import com.example.mybiodata.ui.detail.DetailSkillFragment

class SkillAdapter(private var skills: List<Skill>, private val fragment: Fragment) : RecyclerView.Adapter<SkillAdapter.SkillViewHolder>() {
    inner class SkillViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val binding = ItemSkillBinding.bind(itemView)
        val logo: ImageView = binding.logo
        val title: TextView = binding.title
        val detail: TextView = binding.detail

        fun bind(skill: Skill) {
            itemView.setOnClickListener {
                val detailSkillFragment = DetailSkillFragment()
                val args = Bundle()
                args.putParcelable("skill", skill)
                detailSkillFragment.arguments = args

                val fragmentManager: FragmentManager = fragment.requireActivity().supportFragmentManager
                fragmentManager.beginTransaction()
                    .replace(R.id.recyclerView, detailSkillFragment)
                    .addToBackStack(null)
                    .commit()
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SkillViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_skill, parent, false)
        return SkillViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: SkillViewHolder, position: Int) {
        val skill = skills[position]
        holder.logo.setImageResource(skill.logoResource)
        holder.title.text = skill.title
        holder.detail.text = skill.detail

        holder.bind(skill)
    }

    override fun getItemCount(): Int {
        return skills.size
    }

    fun updateData(newSkills: List<Skill>) {
        skills = newSkills
        notifyDataSetChanged() // Memperbarui tampilan RecyclerView
    }
}