package com.example.mybiodata.ui.detail

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.mybiodata.R
import com.example.mybiodata.ui.skill.Skill

class DetailSkillAdapter(private val skill: Skill) : RecyclerView.Adapter<DetailSkillAdapter.DetailSkillViewHolder>() {

    inner class DetailSkillViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val logo: ImageView = itemView.findViewById(R.id.logoDetail)
        val title: TextView = itemView.findViewById(R.id.titleDetail)
        val detail: TextView = itemView.findViewById(R.id.detailSkill)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DetailSkillViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.fragment_detail_skill, parent, false)
        return DetailSkillViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: DetailSkillViewHolder, position: Int) {
        holder.logo.setImageResource(skill.logoResource)
        holder.title.text = skill.title
        holder.detail.text = skill.detail
    }

    override fun getItemCount(): Int {
        return 1
    }
}
