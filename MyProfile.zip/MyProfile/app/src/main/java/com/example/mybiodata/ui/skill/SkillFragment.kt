package com.example.mybiodata.ui.skill

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mybiodata.R
import com.example.mybiodata.databinding.FragmentSkillBinding

class SkillFragment : Fragment() {

    private var _binding: FragmentSkillBinding? = null
    private val binding get() = _binding!!

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: SkillAdapter
    private lateinit var searchEditText: EditText
    private var skillList: List<Skill> = ArrayList()
    private var filteredSkillList: List<Skill> = ArrayList()

    private val handler = Handler(Looper.getMainLooper())
    private val delay = 1250L

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSkillBinding.inflate(inflater, container, false)
        val root: View = binding.root

        recyclerView = root.findViewById(R.id.recyclerView)
        searchEditText = root.findViewById(R.id.searchEditText)

        adapter = SkillAdapter(filteredSkillList, this)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        skillList = getSkillList()
        filteredSkillList = ArrayList(skillList)
        adapter.updateData(filteredSkillList)

        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {}

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                handler.removeCallbacksAndMessages(null)
                handler.postDelayed({
                    performSearch(s.toString())
                }, delay)
            }
        })

        return root
    }

    private fun getSkillList(): List<Skill> {
        return listOf(
            Skill(R.drawable.java, "Java", "Java adalah bahasa pemrograman tingkat tinggi yang awalnya dikembangkan oleh Sun Microsystems (sekarang dimiliki oleh Oracle)."),
            Skill(R.drawable.php,"PHP", "PHP adalah bahasa pemrograman server-side yang dirancang khusus untuk pengembangan web."),
            Skill(R.drawable.mysql,"MYSQL", "MySQL adalah sistem manajemen basis data (DBMS) open-source yang terkenal karena kecepatan, keandalan, dan kinerjanya."),
            Skill(R.drawable.js,"JAVASCRIPT", "JavaScript adalah bahasa pemrograman yang digunakan untuk mengembangkan konten web dinamis dan interaktif di sisi klien (browser)."),
            Skill(R.drawable.html,"HTML", "HTML (HyperText Markup Language) adalah bahasa markup yang digunakan untuk membuat struktur dasar halaman web."),
            Skill(R.drawable.css,"CSS", "CSS (Cascading Style Sheets) adalah bahasa yang digunakan untuk mengendalikan tampilan dan tata letak elemen HTML."),
            Skill(R.drawable.kotlin,"KOTLIN", "Kotlin adalah bahasa pemrograman modern yang kompatibel dengan Java."),
            Skill(R.drawable.json,"JSON", "JSON (JavaScript Object Notation) adalah format pertukaran data yang ringan dan mudah dibaca oleh manusia dan mudah dimengerti oleh mesin."),
        )
    }

    private fun performSearch(query: String) {
        filteredSkillList = skillList.filter { it.title.contains(query, true) }
        adapter.updateData(filteredSkillList)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
